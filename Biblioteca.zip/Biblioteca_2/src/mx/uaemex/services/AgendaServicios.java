package mx.uaemex.services;

import java.util.List;
import mx.uaemex.dto.Alumno;
import mx.uaemex.dto.Libro;
import mx.uaemex.dto.Prestamo;
import mx.uaemex.dto.Profesor;
import mx.uaemex.facade.AlumnoFacade;
import mx.uaemex.facade.LibroFacade;
import mx.uaemex.facade.PrestamoFacade;
import mx.uaemex.facade.ProfesorFacade;

/**
 *
 * @author mi
 */
public class AgendaServicios {

    AlumnoFacade alumnoFacade = new AlumnoFacade();

    public void agregarAlumno(Alumno alumno) {
        alumnoFacade.agregar(alumno);
    }

    public void eliminiarAlumno(Alumno alumno) {
        alumnoFacade.eliminiar(alumno);
    }

    public void buscarAlumno(Alumno alumno) {
        alumnoFacade.buscar(alumno);
    }

    public void actualizarAlumno(Alumno alumno) {
        alumnoFacade.actualizar(alumno);
    }

    public List<Alumno> readAlumno() {

        return alumnoFacade.read();
    }

    LibroFacade libroFacade = new LibroFacade();

    public void agregarLibro(Libro libro) {
        libroFacade.agregar(libro);
    }

    public void eliminiarLibro(Libro libro) {
        libroFacade.eliminiar(libro);
    }

    public void buscarLibro(Libro libro) {
        libroFacade.buscar(libro);
    }

    public void actualizarLibro(Libro libro) {
        libroFacade.actualizar(libro);
    }

    public List<Libro> readLibro() {

        return libroFacade.read();
    }

    PrestamoFacade prestamoFacade = new PrestamoFacade();

    public void agregarPrestamo(Prestamo prestamo) {
        prestamoFacade.agregar(prestamo);
    }

    public void eliminiarPrestamo(Prestamo prestamo) {
        prestamoFacade.eliminiar(prestamo);
    }

    public void buscarPrestamo(Prestamo prestamo) {
        prestamoFacade.buscar(prestamo);
    }

    public void actualizarPrestamo(Prestamo prestamo) {
        prestamoFacade.actualizar(prestamo);
    }

    public List<Prestamo> readPrestamo() {

        return prestamoFacade.read();
    }

    ProfesorFacade profesorFacade = new ProfesorFacade();

    public void agregarProfesor(Profesor profesor) {
        profesorFacade.agregar(profesor);
    }

    public void eliminiarProfesor(Profesor profesor) {
        profesorFacade.eliminiar(profesor);
    }

    public void buscarProfesor(Profesor profesor) {
        profesorFacade.buscar(profesor);
    }

    public void actualizarProfesor(Profesor profesor) {
        profesorFacade.actualizar(profesor);
    }

    public List<Profesor> readProfesor() {

        return profesorFacade.read();
    }

}
