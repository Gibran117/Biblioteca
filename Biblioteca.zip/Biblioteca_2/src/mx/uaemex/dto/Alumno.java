package mx.uaemex.dto;

/**
 *
 * @author mi
 */
public class Alumno extends Persona {
    
    private int id;
    private int NumeroC;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getNumeroC() {
        return NumeroC;
    }

    public void setNumeroC(int NumeroC) {
        this.NumeroC = NumeroC;
    }

    @Override
    public String toString() {
        return "Alumno{" + "id=" + id + ", NumeroC=" + NumeroC + '}'+",nombre=" + Alumno.super.getNombre() + ", apellido paterno=" + Alumno.super.getApellidoP() + ", apellido Materno=" + Alumno.super.getApellidoM() + "; Sexo=" + Alumno.super.getSexo();
    }
    
    
    
}
