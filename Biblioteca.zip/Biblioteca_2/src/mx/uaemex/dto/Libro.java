package mx.uaemex.dto;

/**
 *
 * @author mi
 */
public class Libro {
   
    private int id;
    private String NombreL;
    private long ISBN;
    private String Autor;
    private String Editorial;
    private String Categoria;
    private int Stock;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreL() {
        return NombreL;
    }

    public void setNombreL(String NombreL) {
        this.NombreL = NombreL;
    }

    public long getISBN() {
        return ISBN;
    }

    public void setISBN(long ISBN) {
        this.ISBN = ISBN;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }

    public String getEditorial() {
        return Editorial;
    }

    public void setEditorial(String Editorial) {
        this.Editorial = Editorial;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        this.Stock = Stock;
    }

    @Override
    public String toString() {
        return "Libro{" + "id=" + id + ", NombreL=" + NombreL + ", ISBN=" + ISBN + ", Autor=" + Autor + ", Editorial=" + Editorial + ", Categoria=" + Categoria + ", Stock=" + Stock + '}';
    }

    
}
