package mx.uaemex.dto;

import java.util.Date;
import java.util.List;

/**
 *
 * @author mi
 */
public class Prestamo {
    
    private int id;
    private int Folio;
    private Date FechaP = new Date();
    private Date FechaE = new Date();
    private String Estatus;
    private List<Libro> Libros;
    private Persona persona;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFolio() {
        return Folio;
    }

    public void setFolio(int Folio) {
        this.Folio = Folio;
    }

    public Date getFechaP() {
        return FechaP;
    }

    public void setFechaP(Date FechaP) {
        this.FechaP = FechaP;
    }

    public Date getFechaE() {
        return FechaE;
    }

    public void setFechaE(Date FechaE) {
        this.FechaE = FechaE;
    }

    public String getEstatus() {
        return Estatus;
    }

    public void setEstatus(String Estatus) {
        this.Estatus = Estatus;
    }

    public List<Libro> getLibros() {
        return Libros;
    }

    public void setLibros(List<Libro> Libros) {
        this.Libros = Libros;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public String toString() {
        return "Prestamo{" + "id=" + id + ", Folio=" + Folio + ", FechaP=" + FechaP + ", FechaE=" + FechaE + ", Estatus=" + Estatus + ", Libros=" + Libros + ", persona=" + persona + '}';
    }
    
    
    
}
