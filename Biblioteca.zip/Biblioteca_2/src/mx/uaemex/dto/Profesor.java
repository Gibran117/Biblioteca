package mx.uaemex.dto;

/**
 *
 * @author mi
 */
public class Profesor extends Persona {
    
    private int id;
    private int NumeroC;

    @Override
    public int getId() {
        return id;
    }

    @Override
    public void setId(int id) {
        this.id = id;
    }

    public int getNumeroC() {
        return NumeroC;
    }

    public void setNumeroC(int NumeroC) {
        this.NumeroC = NumeroC;
    }

    @Override
    public String toString() {
        return "Profesor{" + "id=" + id + ", NumeroC=" + NumeroC + '}'+",nombre=" + Profesor.super.getNombre() + ", apellido paterno=" + Profesor.super.getApellidoP() + ", apellido Materno=" + Profesor.super.getApellidoM() + "; Sexo=" + Profesor.super.getSexo();
    }

}
