package mx.uaemex.test;

import java.util.List;
import mx.uaemex.dto.Alumno;
import mx.uaemex.dto.Libro;
import mx.uaemex.dto.Prestamo;
import mx.uaenex.dao.AlumnoDao;
import mx.uaenex.dao.LibroDao;
import mx.uaenex.dao.PrestamoDao;
import mx.uaenex.dao.ProfesorDao;

/**
 *
 * @author mi
 */
public class Test {

    AlumnoDao alumnoDao = new AlumnoDao();
    LibroDao libroDao = new LibroDao();
    PrestamoDao prestamoDao = new PrestamoDao();
    ProfesorDao profesorDao = new ProfesorDao();

    public void testCrearPrestamo(Prestamo prestamo) {
        prestamoDao.agragarPrestamo(prestamo);
        System.out.println("Fin agregar prestamo");

    }

    public void testCrearLibro(Libro libro) {
        libroDao.agragaLibro(libro);
        System.out.println("Fin agrega libro");

    }

    public void testCrearAlumno(Alumno alumno) {
        alumnoDao.agragarAlumno(alumno);
        System.out.println("Fin agregar alumno");
    }

    public void consultarPrestamo() {

        Prestamo p = prestamoDao.buscarPrestamo(1);
        System.out.println("Bsqueda por id  " + p.toString());
    }

    public void consultarTodos() {
        List<Prestamo> prestamos = prestamoDao.imprimirtListaPrestamos();
        for (Prestamo p : prestamos) {
            System.out.println(p.toString());
        }

    }
}
