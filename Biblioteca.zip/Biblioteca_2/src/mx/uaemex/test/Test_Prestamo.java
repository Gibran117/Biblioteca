package mx.uaemex.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import mx.uaemex.dto.Alumno;
import mx.uaemex.dto.Libro;
import mx.uaemex.dto.Prestamo;

/**
 *
 * @author mi
 */
public class Test_Prestamo {
    
    public static void main(String[] args) {
        
        //Alumno
        Alumno alumno1 = new Alumno();
        
        alumno1.setId(01);
        alumno1.setNumeroC(2223770);
        alumno1.setNombre("Osvaldo Gibran");
        alumno1.setApellidoP("Arriaga");
        alumno1.setApellidoM("Aguilar");
        alumno1.setSexo("Masculino");
        
        //Libro 1
        Libro libro1 = new Libro();
        libro1.setId(1);
        libro1.setNombreL("¿Quien mato a los Robins?");
        libro1.setAutor("Bill Adler");
        libro1.setEditorial("Ediciones Orbis, S.A.");
        //libro1.getISBN(8475307728);
        libro1.setCategoria("Suspenso");
        libro1.setStock(5);
        
        List <Libro> listalibros1 = new ArrayList<>();
        listalibros1.add(libro1);
        //listalibros1.add(libro2);
        //listalibros1.add(libro3);
        
        //Prestamo
        Prestamo prestamo1 = new Prestamo();
        Date fechaIni1 =new Date();
        prestamo1.setId(1);
        prestamo1.setFolio(00001);
        prestamo1.setFechaP(fechaIni1);
        prestamo1.setPersona(alumno1);
        prestamo1.setLibros(listalibros1);
        
        //Alumno 2
        Alumno alumno2 = new Alumno();
        
        alumno2.setId(01);
        alumno2.setNumeroC(2220001);
        alumno2.setNombre("Javier");
        alumno2.setApellidoP("Galvan");
        alumno2.setApellidoM("Estrada");
        alumno2.setSexo("Masculino");
        
        //Libro 2
        Libro libro2 = new Libro();
        libro2.setId(2);
        libro2.setNombreL("¿Pot qué a mí?");
        libro2.setAutor("Valeria Piassa Polizzi");
        libro2.setEditorial("Alfaguara");
        //libro2.getISBN(9789681909208);
        libro2.setCategoria("Informativo");
        libro2.setStock(2);
        
        List <Libro> listalibros2 = new ArrayList<>();
        //listalibros2.add(libro1);
        listalibros2.add(libro2);
        //listalibros2.add(libro3);
        
        //Prestamo 2
        Prestamo prestamo2 = new Prestamo();
        Date fechaIni2 =new Date();
        prestamo2.setId(2);
        prestamo2.setFolio(00002);
        prestamo2.setFechaP(fechaIni2);
        prestamo2.setPersona(alumno2);
        prestamo2.setLibros(listalibros2);
        
        //Alumno 3
        Alumno alumno3 = new Alumno();
        
        alumno3.setId(03);
        alumno3.setNumeroC(2220002);
        alumno3.setNombre("Daniel");
        alumno3.setApellidoP("Molina");
        alumno3.setApellidoM("Galeana");
        alumno3.setSexo("Masculino");
        
        //Libro 3
        Libro libro3 = new Libro();
        libro3.setId(3);
        libro3.setNombreL("Codigo da vinci");
        libro3.setAutor("Dan Brown");
        libro3.setEditorial("Umbriel");
        //libro1.getISBN(8495618605;
        libro3.setCategoria("Novela");
        libro3.setStock(7);
        
        List <Libro> listalibros3 = new ArrayList<>();
        //listalibros3.add(libro1);
        //listalibros3.add(libro2);
        listalibros3.add(libro3);
        
        //Prestamo 3
        Prestamo prestamo3 = new Prestamo();
        Date fechaIni3 =new Date();
        prestamo3.setId(3);
        prestamo3.setFolio(00003);
        prestamo3.setFechaP(fechaIni3);
        prestamo3.setPersona(alumno3);
        prestamo3.setLibros(listalibros3);
        
        Test test1 = new Test();
        test1.testCrearAlumno(alumno1);
        test1.testCrearAlumno(alumno2);
        test1.testCrearAlumno(alumno3);
        test1.testCrearLibro(libro1);
        test1.testCrearLibro(libro2);
        test1.testCrearLibro(libro3);
        test1.testCrearPrestamo(prestamo1);
        test1.testCrearPrestamo(prestamo2);
        test1.testCrearPrestamo(prestamo3);

        test1.consultarTodos();
        test1.consultarPrestamo();
        
    }
    
}
