package mx.uaemex.facade;

import java.util.List;
import mx.uaemex.dto.Profesor;

/**
 *
 * @author mi
 */
public class ProfesorFacade {
    
    ProfesorFacade profesorDAO = new ProfesorFacade();

    public void agregar(Profesor profesor) {
        profesorDAO.agregar(profesor);
    }

    public void eliminiar(Profesor profesor) {
        profesorDAO.eliminiar(profesor);
    }

    public void buscar(Profesor profesor) {
        profesorDAO.buscar(profesor);
    }

    public void actualizar(Profesor profesor) {
        profesorDAO.actualizar(profesor);
    }

    public List<Profesor> read() {

        return profesorDAO.read();

    }
}
