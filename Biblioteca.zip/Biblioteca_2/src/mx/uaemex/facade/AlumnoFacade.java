package mx.uaemex.facade;

import java.util.List;
import mx.uaemex.dto.Alumno;

/**
 *
 * @author mi
 */
public class AlumnoFacade {

    AlumnoFacade alumnoDAO = new AlumnoFacade();

    public void agregar(Alumno alumno) {
        alumnoDAO.agregar(alumno);
    }

    public void eliminiar(Alumno alumno) {
        alumnoDAO.eliminiar(alumno);
    }

    public void buscar(Alumno alumno) {
        alumnoDAO.buscar(alumno);
    }

    public void actualizar(Alumno alumno) {
        alumnoDAO.actualizar(alumno);
    }

    public List<Alumno> read() {
        
        return alumnoDAO.read();

    }

}
