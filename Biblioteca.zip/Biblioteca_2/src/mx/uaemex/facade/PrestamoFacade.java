package mx.uaemex.facade;

import java.util.List;
import mx.uaemex.dto.Prestamo;

/**
 *
 * @author mi
 */
public class PrestamoFacade {

    PrestamoFacade prestamoDAO = new PrestamoFacade();

    public void agregar(Prestamo prestamo) {
        prestamoDAO.agregar(prestamo);
    }

    public void eliminiar(Prestamo prestamo) {
        prestamoDAO.eliminiar(prestamo);
    }

    public void buscar(Prestamo prestamo) {
        prestamoDAO.buscar(prestamo);
    }

    public void actualizar(Prestamo prestamo) {
        prestamoDAO.actualizar(prestamo);
    }

    public List<Prestamo> read() {

        return prestamoDAO.read();

    }

}
