package mx.uaemex.facade;

import java.util.List;
import mx.uaemex.dto.Libro;

/**
 *
 * @author mi
 */
public class LibroFacade {

    LibroFacade libroDAO = new LibroFacade();

    public void agregar(Libro libro) {
        libroDAO.agregar(libro);
    }

    public void eliminiar(Libro libro) {
        libroDAO.eliminiar(libro);
    }

    public void buscar(Libro libro) {
        libroDAO.buscar(libro);
    }

    public void actualizar(Libro libro) {
        libroDAO.actualizar(libro);
    }

    public List<Libro> read() {

        return libroDAO.read();

    }

}
